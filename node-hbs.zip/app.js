const express = require("express");
const path = require("path");
const { engine } = require("express-handlebars");

const app = express();
const PORT = process.env.PORT || 5000;

app.engine(".hbs", engine({ extname: ".hbs", defaultLayout: "main" }));
app.set("view engine", ".hbs");
app.set("views", path.join(__dirname, "views"));
app.use("/static", express.static("public"));

// setup middleware
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

const admins = [
  { id: 1, name: "admin1", email: "admin1@gmail.com", pass: 1 },
  { id: 2, name: "admin2", email: "admin2@gmail.com", pass: 2 },
  { id: 3, name: "admin3", email: "admin3@gmail.com", pass: 3 },
  { id: 4, name: "admin4", email: "admin4@gmail.com", pass: 4 },
];

const students = [
  {
    id: 1,
    name: "ahmed",
    email: "ahmed@gmail.com",
    pass: 1,
    class: 1,
    deg: 74,
    arabic: 60,
    english: 80,
    math: 80,
    biology: 50,
    history: 70,
    result: "pass",
  },
  {
    id: 2,
    name: "mohammed",
    email: "mohammed@gmail.com",
    pass: 2,
    class: 1,
    deg: 90,
    arabic: 88,
    english: 90,
    math: 85,
    biology: 70,
    history: 80,
    result: "pass",
  },
  {
    id: 3,
    name: "hassan",
    email: "hassan@gmail.com",
    pass: 3,
    class: 3,
    deg: 35,
    arabic: 16,
    english: 40,
    math: 25,
    biology: 70,
    history: 35,
    result: "faill",
  },
  {
    id: 4,
    name: "omer",
    email: "omer@gmail.com",
    pass: 4,
    class: 4,
    deg: 70,
    arabic: 88,
    english: 50,
    math: 85,
    biology: 50,
    history: 60,
    result: "pass",
  },
];

app.get("/", (req, res) => {
  res.render("home");
});

app.get("/register", (req, res) => {
  res.render("register");
});

app.get("/dashboard", (req, res) => {
  res.render("dashboard", { students });
});

app.get("/login", (req, res) => {
  res.render("login");
});

app.post("/register", async (req, res) => {
  let err = "",
    msg = "";
  const { name } = await req.body;
  users.forEach((user) => {
    if (user.name == name) {
      err = "user exist";
    }
  });
  if (err.length > 0) {
    res.render("register", { err });
  } else {
    res.render("home", { msg: "Welcome" });
  }
});

app.post("/login", async (req, res) => {
  let err,
    found = false,
    student;
  const { email, pass } = await req.body;
  students.forEach((user) => {
    if (user.email == email && user.pass == pass) {
      found = true;
      student = user;
    } else {
      err = "wrong user";
    }
  });
  if (found) {
    return res.render("student", { student });
  } else {
    res.render("login", { err });
  }
});

app.get("/adminlogin", async (req, res) => {
  res.render("adminlogin");
});

app.post("/adminlogin", async (req, res) => {
  let err;
  const { email, pass } = await req.body;
  let found = false;
  admins.forEach((admin) => {
    if (admin.email == email && admin.pass == pass) {
      found = true;
    } else {
      err = "wrong user";
    }
  });
  if (found) {
    return res.render("dashboard", { students });
  } else {
    res.render("adminlogin", { err });
  }
});

app.get("/logout", (req, res) => {
  res.redirect("/");
});

app.get("/students", (req, res) => {
  let found = false;
  const { id } = req.query;
  console.log(req.query);
  let student;
  students.forEach((user) => {
    if (user.id == id) {
      found = true;
      student = user;
    } else {
      err = "student not found";
    }
  });
  if (found) {
    res.render("studentinfo", { student });
  } else {
    res.render("dashboard", { err });
  }
});
app.get("/delete", (req, res) => {
  const { id } = req.query;
  let index = null;
  students.forEach((element) => {
    if (element.id == id) {
      index = students.indexOf(element);
      if (index > -1) {
        students.splice(index, 1);
      }
    }
  });
  res.render("dashboard", { students });
});
app.listen(PORT, () => console.log(`Server Runing On Port ${PORT}`));
